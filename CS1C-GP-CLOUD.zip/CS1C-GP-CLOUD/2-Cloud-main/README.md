2D Graphics Modeler Class Project  
CS1C GROUP PROJECT - TEAM CLOUD  

Team Members:  
Esmar Walkman  
Evan Stewart  
Joshua Baxter  
Kaiss Asadi  
Max Tan  
Yu-chen Chung  
Stephanie Tucker  
Min Jeon  