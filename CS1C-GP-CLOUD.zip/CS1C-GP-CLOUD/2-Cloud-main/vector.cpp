//vector.cpp
